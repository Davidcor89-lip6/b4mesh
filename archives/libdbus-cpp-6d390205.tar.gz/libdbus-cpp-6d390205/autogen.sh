#!/bin/sh

./bootstrap && ./configure $@
