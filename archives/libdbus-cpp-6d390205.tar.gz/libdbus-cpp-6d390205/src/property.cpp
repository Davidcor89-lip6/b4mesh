/*
 *
 *  D-Bus++ - C++ bindings for D-Bus
 *
 *  Copyright (C) 2005-2007  Paolo Durante <shackan@gmail.com>
 *
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <dbus-c++/debug.h>
#include <dbus-c++/property.h>

#include <dbus-c++/introspection.h>

using namespace DBus;

static const char *properties_name = "org.freedesktop.DBus.Properties";

PropertiesAdaptor::PropertiesAdaptor()
  : InterfaceAdaptor(properties_name)
{
  dbusxx_register_method(PropertiesAdaptor, Get, Get);
  dbusxx_register_method(PropertiesAdaptor, Set, Set);
  dbusxx_register_method(PropertiesAdaptor, GetAll, GetAll);
}

Message PropertiesAdaptor::Get(const CallMessage &call)
{
  MessageIter ri = call.reader();

  std::string iface_name;
  std::string property_name;

  ri >> iface_name >> property_name;

  debug_log("requesting property %s on interface %s", property_name.c_str(), iface_name.c_str());

  InterfaceAdaptor *interface = (InterfaceAdaptor *) find_interface(iface_name);

  if (!interface)
    throw ErrorFailed("requested interface not found");

  Variant& value = interface->get_property(property_name);

  on_get_property(*interface, property_name, value);

  ReturnMessage reply(call);

  MessageIter wi = reply.writer();

  wi << value;
  return reply;
}

Message PropertiesAdaptor::Set(const CallMessage &call)
{
  MessageIter ri = call.reader();

  std::string iface_name;
  std::string property_name;
  Variant value;

  ri >> iface_name >> property_name >> value;

  InterfaceAdaptor *interface = (InterfaceAdaptor *) find_interface(iface_name);

  if (!interface)
    throw ErrorFailed("requested interface not found");

  on_set_property(*interface, property_name, value);

  interface->set_property(property_name, value);

  ReturnMessage reply(call);

  return reply;
}

Message PropertiesAdaptor::GetAll(const CallMessage &call)
{
  MessageIter ri = call.reader();
  std::string iface_name;
  ri >> iface_name;
  InterfaceAdaptor *interface = find_interface(iface_name);
  if (!interface)
    throw ErrorFailed("requested interface not found");
  std::map<std::string, Variant> ret;
  PropertyTable::iterator iter = _properties.begin(),
			  end = _properties.end();
  for (; iter != end; ++iter) {
    try {
      Variant& value = interface->get_property(iter->first);
      on_get_property(*interface, iter->first, value);
      ret.insert(std::make_pair(iter->first, value));
    } catch (const Error&) {
    }
  }
  ReturnMessage reply(call);
  MessageIter wi = reply.writer();
  wi << ret;
  return reply;
}

void PropertiesAdaptor::PropertiesChanged(const std::string& interface_name,
					  const std::map<std::string,
							 Variant>&
					    changed_properties,
					  const std::vector<std::string>&
					    invalidated_properties) {
  SignalMessage sig("PropertiesChanged");
  MessageIter wi = sig.writer();
  wi << interface_name << changed_properties << invalidated_properties;
  emit_signal(sig);
}

const IntrospectedInterface *PropertiesAdaptor::introspect() const
{
  static IntrospectedArgument Get_args[] =
  {
    { "interface_name", "s", true },
    { "property_name", "s", true },
    { "value", "v", false },
    { 0, 0, 0 }
  };
  static IntrospectedArgument Set_args[] =
  {
    { "interface_name", "s", true },
    { "property_name", "s", true },
    { "value", "v", true },
    { 0, 0, 0 }
  };
  static IntrospectedArgument GetAll_args[] =
  {
    { "interface_name", "s", true },
    { "props", "a{sv}", false },
    { 0, 0, 0 }
  };
  static IntrospectedArgument PropertiesChanged_args [] =
  {
    { "interface_name", "s", false },
    { "changed_properties", "a{sv}", false },
    { "invalidated_properties", "as", false },
    { 0, 0, 0 }
  };
  static IntrospectedMethod Properties_methods[] =
  {
    { "Get", Get_args },
    { "Set", Set_args },
    { "GetAll", GetAll_args },
    { 0, 0 }
  };
  static IntrospectedMethod Properties_signals[] =
  {
    { "PropertiesChanged", PropertiesChanged_args },
    { 0, 0 }
  };
  static IntrospectedProperty Properties_properties[] =
  {
    { 0, 0, 0, 0 }
  };
  static IntrospectedInterface Properties_interface =
  {
    properties_name,
    Properties_methods,
    Properties_signals,
    Properties_properties
  };
  return &Properties_interface;
}

PropertiesProxy::PropertiesProxy()
  : InterfaceProxy(properties_name)
{
  dbusxx_connect_signal(PropertiesProxy, PropertiesChanged,
			unmarshall_properties_changed);
}

Variant PropertiesProxy::Get(const std::string& interface_name,
			     const std::string& property_name)
{
  CallMessage call;
  MessageIter wi = call.writer();
  wi << interface_name << property_name;
  call.member("Get");
  Message reply = invoke_method(call);
  MessageIter ri = reply.reader();
  Variant ret;
  ri >> ret;
  return ret;
}

void PropertiesProxy::Set(const std::string& interface_name,
			  const std::string& property_name,
			  const Variant& value)
{
  CallMessage call;
  MessageIter wi = call.writer();
  wi << interface_name << property_name << value;
  call.member("Set");
  Message ret = invoke_method(call);
}

std::map<std::string, Variant>
PropertiesProxy::GetAll(const std::string& interface) {
  CallMessage call;
  MessageIter wi = call.writer();
  wi << interface;
  call.member("GetAll");
  Message reply = invoke_method(call);
  MessageIter ri = reply.reader();
  std::map<std::string, Variant> ret;
  ri >> ret;
  return ret;
}

void PropertiesProxy::PropertiesChanged(const std::string&,
					const std::map<std::string, Variant>&,
					const std::vector<std::string>&) {
}

void PropertiesProxy::unmarshall_properties_changed(const SignalMessage& sig) {
  MessageIter ri = sig.reader();
  std::string interface_name;
  std::map<std::string, Variant> changed_properties;
  std::vector<std::string> invalidated_properties;
  ri >> interface_name;
  ri >> changed_properties;
  ri >> invalidated_properties;
  PropertiesChanged(interface_name, changed_properties,
		    invalidated_properties);
}
