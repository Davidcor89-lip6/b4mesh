#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <dbus-c++/dbus.h>
#include <dbus-c++/asio-integration.h>
#include <boost/asio/signal_set.hpp>
#include <boost/asio/streambuf.hpp>
#include <boost/asio/read_until.hpp>
#include <iostream>

#include "echo-client-glue.h"

struct EchoClient
  : public org::freedesktop::DBus::EchoDemo_proxy,
    public DBus::IntrospectableProxy,
    public DBus::ObjectProxy {
  using DBus::ObjectProxy::ObjectProxy;
  void Echoed(const DBus::Variant &value) {
    if (value.signature() == "s") {
      std::string str;
      auto iterator = value.reader();
      iterator >> str;
      std::cout << "echoed:" << str << std::endl;
    } else
      std::cout << "echoed type: " << value.signature() << std::endl;
  }
};

static const char *ECHO_SERVER_NAME = "org.freedesktop.DBus.Examples.Echo";
static const char *ECHO_SERVER_PATH = "/org/freedesktop/DBus/Examples/Echo";

struct Client {
  EchoClient proxy;
  boost::asio::streambuf buffer;
  boost::asio::posix::stream_descriptor input;

  Client(boost::asio::io_context& ctx, DBus::Connection& conn)
    : proxy{conn, ECHO_SERVER_PATH, ECHO_SERVER_NAME},
      buffer{},
      input{ctx, ::dup(STDIN_FILENO)} {
    read_stdin();
  }

  void stdin_handler(const boost::system::error_code& ec, const int ) {
    if (ec == boost::asio::error::operation_aborted)
      return;
    std::istream is{&buffer};
    std::string line;
    std::getline(is, line);
    if (not line.empty() and line[0] %2) {
      DBus::Variant variant;
      auto iter = variant.writer();
      iter << line;
      proxy.Echo(variant);
    } else {
      std::cout << proxy.Hello(line) << std::endl;
    }
    read_stdin();
  }

  void read_stdin() {
    boost::asio::async_read_until(input, buffer, '\n',
				  [this](auto a, auto b) {
				    stdin_handler(a, b);
				  });
  }

};

int main()
{
  boost::asio::io_context ctx;

  DBus::Asio::Dispatcher dispatcher{ctx};
  DBus::default_dispatcher = &dispatcher;
  boost::asio::signal_set sighandler{ctx, SIGINT, SIGTERM};
  sighandler.async_wait([&ctx](const boost::system::error_code&, const int&) {
    ctx.stop();
  });

  DBus::Connection conn = DBus::Connection::SessionBus();

  Client client{ctx, conn};

  client.read_stdin();

  ctx.run();

  std::cout << "terminating" << std::endl;


  return 0;
}
