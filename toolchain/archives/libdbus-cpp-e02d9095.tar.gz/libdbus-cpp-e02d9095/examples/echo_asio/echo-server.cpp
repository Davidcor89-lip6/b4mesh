#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include "echo-server.h"
#include <unistd.h>
#include <stdio.h>
#include <boost/asio/signal_set.hpp>
#include <chrono>

static const char *ECHO_SERVER_NAME = "org.freedesktop.DBus.Examples.Echo";
static const char *ECHO_SERVER_PATH = "/org/freedesktop/DBus/Examples/Echo";

EchoServer::EchoServer(DBus::Connection &connection,
		       boost::asio::io_context& io_context)
  : DBus::ObjectAdaptor{connection, ECHO_SERVER_PATH},
    timer{io_context} {
}

int32_t EchoServer::Random()
{
  return rand();
}

std::string EchoServer::Hello(const std::string &name)
{
  return "Hello " + name + "!";
}

DBus::Variant EchoServer::Echo(const DBus::Variant &value)
{
  timer.expires_from_now({0,0,1,0});
  timer.async_wait([value, this](const boost::system::error_code&) {
    // this will echo the value even when cancelled, this could help
    this->Echoed(value);
  });

  return value;
}

std::vector< uint8_t > EchoServer::Cat(const std::string &file)
{
  FILE *handle = fopen(file.c_str(), "rb");

  if (!handle) throw DBus::Error("org.freedesktop.DBus.EchoDemo.ErrorFileNotFound", "file not found");

  uint8_t buff[1024];

  size_t nread = fread(buff, 1, sizeof(buff), handle);

  fclose(handle);

  return std::vector< uint8_t > (buff, buff + nread);
}

int32_t EchoServer::Sum(const std::vector<int32_t>& ints)
{
  int32_t sum = 0;

  for (size_t i = 0; i < ints.size(); ++i) sum += ints[i];

  return sum;
}

std::map< std::string, std::string > EchoServer::Info()
{
  std::map< std::string, std::string > info;
  char hostname[HOST_NAME_MAX];

  gethostname(hostname, sizeof(hostname));
  info["hostname"] = hostname;
  info["username"] = getlogin();

  return info;
}

int main()
{
  boost::asio::io_context ctx;

  DBus::Asio::Dispatcher dispatcher{ctx};
  DBus::default_dispatcher = &dispatcher;
  boost::asio::signal_set sighandler{ctx, SIGINT, SIGTERM};
  sighandler.async_wait([&ctx](const boost::system::error_code&, const int&) {
    ctx.stop();
  });

  DBus::Connection conn = DBus::Connection::SessionBus();
  conn.request_name(ECHO_SERVER_NAME);

  EchoServer server(conn, ctx);

  ctx.run();

  server.timer.cancel();

  return 0;
}
