// SPDX-License-Identifier: LGPL-2.1-or-later
#ifndef __DBUSXX_ASIO_INTEGRATION_H
#define __DBUSXX_ASIO_INTEGRATION_H

#include "api.h"
#include "dispatcher.h"

#include <boost/asio/io_context.hpp>
#include <boost/asio/deadline_timer.hpp>
#include <boost/asio/posix/stream_descriptor.hpp>
#include <unordered_set>
#include <memory>

namespace DBus::Asio {

struct DXXAPI Dispatcher : public DBus::Dispatcher {

  struct Timer : Timeout, std::enable_shared_from_this<Timer> {
    Timer(Timeout::Internal* internal, boost::asio::io_context& context);

    /// Called by libdbus-c++ when the wanted timer changes.
    void toggle() override final;
    /// Forcibly cancel the timer and ignore all future timeouts.
    void stop();

  private:
    boost::asio::deadline_timer timer_;
    bool stopped_ = false;
  };

  struct PollWatch : Watch, std::enable_shared_from_this<PollWatch> {
    PollWatch(Watch::Internal* internal,
	      boost::asio::io_context& context);
    /// Called by libdbus-c++ when the wanted fd or flags changes.
    void toggle() override final;
    /// Release the file descriptor and prevent future handlers from running.
    void stop();
    /// Calls stop()
    ~PollWatch();
  private:
    int poll_fd_once(short flag);
    boost::asio::posix::stream_descriptor fd_;
    int posted_flags_ = 0;
    bool stopped_ = false;
  };

  // The documentation on them is lacking and we don't use threads.
  // empty implementations are common anyway.
  void enter() override final {}
  void leave() override final {}

  /// Called by libdbus-c++ to create a D-Bus timeout.
  auto add_timeout(Timeout::Internal* internal) -> Timer* override;
  /// Called by libdbus-c++ to destroy a D-Bus timeout.
  void rem_timeout(Timeout* timeout) override;

  /// Called by libdbus-c++ to create a D-Bus Watch.
  auto add_watch(Watch::Internal* internal) -> PollWatch* override;
  /// Called by libdbus-c++ to destroy a D-Bus Watch.
  void rem_watch(Watch* watch) override;
  /// Called by libdbus-c++ when messages are pending.
  void on_something_to_dispatch() override;

  Dispatcher(boost::asio::io_context& context);

  Dispatcher(const Dispatcher&) = delete;
  Dispatcher(Dispatcher&&) = delete;
  Dispatcher& operator=(Dispatcher&&) = delete;
  Dispatcher& operator=(const Dispatcher&) = delete;

  ~Dispatcher();
private:
  boost::asio::io_context& context;
  // libdbus cannot hold a shared_ptr reference and there is no API for this
  // anyway.  Also, experience shows us it should not be trusted too much,
  // as it destroys things aggressively inside their own handlers.
  // (this could be worked around with hacks like storing a shared_ptr<Timer>
  //  inside Timer, but let's not go there)
  std::unordered_set<std::shared_ptr<Timer>> timers_;
  std::unordered_set<std::shared_ptr<PollWatch>> watchers_;
  bool dispatcher_posted_ = false;
  // Set to true when this object exists and false on destruction.
  // Can be copied to check if this object still exists.
  std::shared_ptr<bool> canary_;
};

} // namespace DBus::Asio

#endif
