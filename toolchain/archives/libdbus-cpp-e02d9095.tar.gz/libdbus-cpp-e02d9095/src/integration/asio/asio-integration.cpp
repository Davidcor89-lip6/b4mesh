#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <dbus-c++/asio-integration.h>
#include <boost/asio/post.hpp>
#include <dbus/dbus.h>

namespace DBus::Asio {

Dispatcher::Timer::Timer(Timeout::Internal* internal,
			 boost::asio::io_context& context)
  : Timeout{internal}, timer_{context} {
}

void Dispatcher::Timer::toggle() {
  timer_.cancel();
  if (not enabled())
    return;

  timer_.expires_from_now(boost::posix_time::millisec(interval()));
  auto shared = shared_from_this();

  // handle() returns a bool, which is false if libdbus-c++ lacks memory
  // and just forgetting about it is perfectly adequate.
  timer_.async_wait([shared](const boost::system::error_code& e) {
		      if (e or shared->stopped_)
			return; // TODO: log
		      shared->handle();
		    });
}

inline void Dispatcher::Timer::stop() {
  stopped_ = true;
  timer_.cancel();
}

Dispatcher::PollWatch::PollWatch(Watch::Internal* internal,
				 boost::asio::io_context& context)
  : Watch{internal}, fd_{context} {
}

void Dispatcher::PollWatch::toggle() {
  const int wanted_fd = enabled() ? descriptor() : -1;
  if (fd_.is_open() && (wanted_fd == -1 || fd_.native_handle() != wanted_fd))
    fd_.release();

  if (wanted_fd == -1)
    return;

  if (not fd_.is_open())
    fd_.assign(wanted_fd);

  auto watch_flags = flags();
  const auto new_flags = watch_flags &~ posted_flags_;
  posted_flags_ = watch_flags;

  auto me = shared_from_this();
  auto handle_event = [me](int dbus_flag) {
    if (not me->stopped_ and me->fd_.is_open()
	and (me->posted_flags_ & dbus_flag)) {
      const auto report_flags = me->posted_flags_ & dbus_flag;
      me->posted_flags_ &=~ dbus_flag;
      me->handle(report_flags);
      // libdbus watches are recurring.
      me->toggle();
    }
  };
  if (new_flags & DBUS_WATCH_READABLE) {
    if (poll_fd_once(POLLIN) == 1)
      post(fd_.get_executor(), std::bind(handle_event, DBUS_WATCH_READABLE));
    else
      fd_.async_read_some(boost::asio::null_buffers(),
			  [handle_event](const auto& error, auto /*zero*/) {
			    if (error != boost::asio::error::operation_aborted)
			      handle_event(DBUS_WATCH_READABLE);
			  });
  }

  if (new_flags & DBUS_WATCH_WRITABLE) {
    if (poll_fd_once(POLLOUT) == 1)
      post(fd_.get_executor(), std::bind(handle_event, DBUS_WATCH_WRITABLE));
    else
      fd_.async_write_some(boost::asio::null_buffers(),
			   [handle_event](const auto& error, auto /*zero*/) {
			     if (error !=
				 boost::asio::error::operation_aborted)
			       handle_event(DBUS_WATCH_WRITABLE);
			   });
  }
}

inline void Dispatcher::PollWatch::stop() {
  stopped_ = true;
  if (fd_.is_open()) {
    // cancel any pending operation
    fd_.cancel();
    // release the fd, so boost does not close it.
    fd_.release();
  }
}

Dispatcher::PollWatch::~PollWatch() {
  stop();
}

inline int Dispatcher::PollWatch::poll_fd_once(short poll_type) {
  struct pollfd poll_fds{fd_.native_handle(), poll_type, 0};
  int poll_ret;
  do {
    poll_ret = poll(&poll_fds, 1, 0);
  } while (poll_ret == -1 && errno == EINTR);
  return poll_ret;
}


auto Dispatcher::add_timeout(Timeout::Internal* internal) -> Timer* {
  auto ret = std::make_shared<Timer>(internal, context);

  ret->toggle();

  return timers_.emplace(std::move(ret)).first->get();
}

void Dispatcher::rem_timeout(Timeout* timeout) {
  auto ptr = static_cast<Timer*>(timeout)->shared_from_this();
  ptr->stop();
  timers_.erase(ptr);
}

auto Dispatcher::add_watch(Watch::Internal* internal) -> PollWatch* {
  auto ret = std::make_shared<PollWatch>(internal, context);

  ret->toggle();

  return watchers_.emplace(std::move(ret)).first->get();
}

void Dispatcher::rem_watch(Watch* watch) {
  auto ptr = static_cast<PollWatch*>(watch)->shared_from_this();
  ptr->stop();
  watchers_.erase(ptr);
}

void Dispatcher::on_something_to_dispatch() {
  if (dispatcher_posted_)
    return;
  auto canary = canary_;
  post(context, [this, canary]() {
    if (*canary == false)
      return;
    dispatcher_posted_ = false;
    this->dispatch_pending();
    if (this->has_something_to_dispatch())
      on_something_to_dispatch();
  });
  dispatcher_posted_ = true;
}

Dispatcher::Dispatcher(boost::asio::io_context& io_context)
  : context{io_context}, canary_{std::make_shared<bool>(true)} {
}

Dispatcher::~Dispatcher() {
  *canary_ = false;
}

} // namespace DBus::Asio
