/*
 *
 *  D-Bus++ - C++ bindings for D-Bus
 *
 *  Copyright (C) 2005-2007  Paolo Durante <shackan@gmail.com>
 *
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <dbus-c++/pendingcall.h>

#include <dbus/dbus.h>

#include "internalerror.h"
#include "pendingcall_p.h"
#include "message_p.h"

using namespace DBus;

PendingCall::Private::Private(DBusPendingCall *dpc)
  : call(dpc), dataslot(-1)
{
  if (!dbus_pending_call_allocate_data_slot(&dataslot))
  {
    throw ErrorNoMemory("Unable to allocate data slot");
  }
}

PendingCall::Private::~Private()
{
  if (dataslot != -1)
  {
    dbus_pending_call_allocate_data_slot(&dataslot);
  }
  dbus_pending_call_unref(call);
}

void PendingCall::Private::notify_stub(DBusPendingCall *, void *data)
{
  PendingCall::Private *pvt = static_cast<PendingCall::Private *>(data);

  auto private_ref = pvt->implicit_dbus_reference;
  PendingCall pc(pvt);
  pvt->implicit_dbus_reference.reset();
  pvt->slot(pc);
}

PendingCall::PendingCall(PendingCall::Private *p)
  : _pvt{p->implicit_dbus_reference}
{
  // This can be called in two cases:
  // 1) right after creating the DBusPendingCall, in which case,
  //    implicit_dbus_reference is null.  we create a shared_ptr out of it and
  //    we store it into the structure itself. Therefore, destroying this
  //    object will not free the structure, which is good.
  //
  // 2) in notify_stub, after the pending call completes.  There we fetch
  //    the ref counter with implicit_dbus_reference.  notify_stub() will then
  //    clear implicit_dbus_reference so that the structure can be freed when
  //    dbus does not reference it.
  if (!p->implicit_dbus_reference) {
    _pvt.reset(p);
    if (!dbus_pending_call_set_notify(p->call, Private::notify_stub, p, NULL))
      throw ErrorNoMemory("Unable to initialize pending call");
    _pvt->implicit_dbus_reference = _pvt;
  }
}

bool PendingCall::completed()
{
  return dbus_pending_call_get_completed(_pvt->call);
}

void PendingCall::cancel()
{
  dbus_pending_call_cancel(_pvt->call);
  _pvt->implicit_dbus_reference.reset();
}

void PendingCall::block()
{
  dbus_pending_call_block(_pvt->call);
}

void PendingCall::data(void *p)
{
  if (!dbus_pending_call_set_data(_pvt->call, _pvt->dataslot, p, NULL))
  {
    throw ErrorNoMemory("Unable to initialize data slot");
  }
}

void *PendingCall::data()
{
  return dbus_pending_call_get_data(_pvt->call, _pvt->dataslot);
}

Slot<void, PendingCall &>& PendingCall::slot()
{
  return _pvt->slot;
}

Message PendingCall::steal_reply()
{
  DBusMessage *dmsg = dbus_pending_call_steal_reply(_pvt->call);
  if (!dmsg)
  {
    dbus_bool_t callComplete = dbus_pending_call_get_completed(_pvt->call);

    if (callComplete)
      throw ErrorNoReply("No reply available");
    else
      throw ErrorNoReply("Call not complete");
  }
  _pvt->implicit_dbus_reference.reset();

  return Message(new Message::Private(dmsg));
}
