/*
 *
 *  D-Bus++ - C++ bindings for D-Bus
 *
 *  Copyright (C) 2005-2007  Paolo Durante <shackan@gmail.com>
 *
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

/* Project */
#include <dbus-c++/pipe.h>
#include <dbus-c++/util.h>
#include <dbus-c++/error.h>

/* STD */
#include <unistd.h>
#include <sys/poll.h>
#include <fcntl.h>
#include <errno.h>
#include <cassert>

using namespace DBus;
using namespace std;

Pipe::Pipe(void(*handler)(const void *data, void *buffer, unsigned int nbyte), const void *data) :
  _handler(handler),
  _fd_write(0),
  _fd_read(0),
  _data(data)
{
  int fd[2];

  if (pipe(fd) == 0)
  {
    _fd_read = fd[0];
    _fd_write = fd[1];
    fcntl(_fd_read, F_SETFL, O_NONBLOCK);
  }
  else
  {
    throw Error("PipeError:errno", toString(errno).c_str());
  }
}

void Pipe::write(const void *buffer, unsigned int nbytes)
{
  // TODO: ignoring return of read/write generates warning; maybe relevant for eventloop work...
  // first write the size into the pipe...
  size_t	offset = 0;
  do {
    ssize_t	ret = ::write(_fd_write,
			      reinterpret_cast<const char*>(&nbytes) + offset,
			      sizeof nbytes - offset);
    if (ret < 0)
      throw Error("PipeError:errno", toString(errno).c_str());
    offset += ret;
  } while (offset < sizeof nbytes);

  // ...then write the real data
  offset = 0;
  do {
    ssize_t	ret = ::write(_fd_write,
			      reinterpret_cast<const char*>(buffer) + offset,
			      nbytes - offset);
    if (ret < 0)
      throw Error("PipeError:errno", toString(errno).c_str());
    offset += ret;
  } while (offset < nbytes);
}

ssize_t Pipe::read(void *buffer, unsigned int &nbytes)
{
  // TODO: ignoring return of read/write generates warning; maybe relevant for eventloop work...
  // first read the size from the pipe...
  size_t	offset = 0;
  do {
    ssize_t	ret = ::read(_fd_read,
			     reinterpret_cast<char*>(&nbytes) + offset,
			     sizeof nbytes - offset);
    if (ret < 0)
      throw Error("PipeError:errno", toString(errno).c_str());
    offset += ret;
  } while (offset < sizeof nbytes);

  //ssize_t size = 0;
  offset = 0;
  do {
    ssize_t	ret = ::read(_fd_read,
			     reinterpret_cast<char*>(buffer) + offset,
			     nbytes - offset);
    if (ret < 0)
      throw Error("PipeError:errno", toString(errno).c_str());
    offset += ret;
  } while (offset < nbytes);

  return nbytes;
}

void Pipe::signal()
{
  if (::write(_fd_write, "\0", 1) < 0)
    throw Error("PipeError:errno", toString(errno).c_str());
}
