#include <dbuscxx_test_generator-client.h>

int main()
{

  return 0;
}
