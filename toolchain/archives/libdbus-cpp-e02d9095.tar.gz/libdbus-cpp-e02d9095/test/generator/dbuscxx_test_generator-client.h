#ifndef DBUSCXX_TEST_GENERATOR_CLIENT_H

#include <dbuscxx_test_generator-client-glue.h>

#endif // DBUSCXX_TEST_GENERATOR_CLIENT_H
