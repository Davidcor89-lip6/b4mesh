#include <dbuscxx_test_generator-server.h>

int main()
{

  return 0;
}
