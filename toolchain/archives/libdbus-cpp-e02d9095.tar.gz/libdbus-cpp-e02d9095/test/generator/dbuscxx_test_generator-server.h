#ifndef DBUSCXX_TEST_GENERATOR_SERVER_H

#include <dbuscxx_test_generator-server-glue.h>

#endif // DBUSCXX_TEST_GENERATOR_SERVER_H

